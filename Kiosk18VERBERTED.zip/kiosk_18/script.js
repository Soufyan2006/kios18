//CODE ZONDER INFO WERKT WEL


//Function to display product information popup
function showProductInfo(name, description, image) {
    const modalContent = `
        <div class="modal">
            <div class="modal-content">
                <span class="close-button" onclick="closeModal()">&times;</span>
                <h2>${name}</h2>
                <img src="${image}" alt="${name}" style="width: 200px; margin-bottom: 10px;">
                <p>${description}</p>
            </div>
        </div>
    `;

    document.body.insertAdjacentHTML('beforeend', modalContent);
}

// Function to close the modal popup
function closeModal() {
    const modal = document.querySelector('.modal');
    if (modal) {
        modal.remove();
    }
}

// Update displayCategory function to include 'Info' button
function displayCategory(category) {
    const menuItemsContainer = document.getElementById("menuItems");
    menuItemsContainer.innerHTML = '';

    const filteredItems = menu.filter(item => item.category === category).slice(0, 10); // Display up to 10 items per category

    filteredItems.forEach(item => {
        const menuItemElement = document.createElement("div");
        menuItemElement.classList.add("menu-item");

        // Create image element
        const imgElement = document.createElement("img");
        imgElement.src = item.image;
        imgElement.alt = item.name;
        imgElement.style.width = "100px"; // Set image width (adjust as needed)
        menuItemElement.appendChild(imgElement);

        // Create item details (name, price, and info button)
        const itemDetails = document.createElement("div");
        itemDetails.classList.add("item-details");
        itemDetails.innerHTML = `
            <p>${item.name}</p>
            <p>$${item.price}</p>
            <button onclick="addToOrder(${JSON.stringify(item)})">Add to Order</button>
            <button class="info-button" onclick="showProductInfo('${item.name}', '${item.description}', '${item.image}')">Info</button>
        `;
        menuItemElement.appendChild(itemDetails);

        // Append menu item to container
        menuItemsContainer.appendChild(menuItemElement);
    });
}



const menu = [
    { id: 1, name: "Tripple-cheese-burger", category: "Fast Food", price: 10, image: "img/Tripplecheeseburger.jpg" },
    { id: 2, name: "Tripple-beef-burger", category: "Fast Food", price: 12, image: "img/Tripplebeefburger.jpg" },
    { id: 3, name: "Long-spicy-beef", category: "Fast Food", price: 7.40, image: "img/long-spicy-beef.jpg" },
    { id: 4, name: "Kidsburger", category: "Fast Food", price: 6.50, image: "img/Kidsburger.jpg" },
    { id: 5, name: "Double-cheese-burger", category: "Fast Food", price: 10.30, image: "img/Doublecheeseburger.jpg" },
    { id: 6, name: "Double-beefburger", category: "Fast Food", price: 9.70, image: "img/doublebeefburger.jpg" },
    { id: 7, name: "Chickenwrap", category: "Fast Food", price: 8, image: "img/chickenwrap.jpg" },
    { id: 8, name: "Cheese burger", category: "Fast Food", price: 8, image: "img/cheeseburger.jpg" },
    { id: 9, name: "Beef-burger", category: "Fast Food", price: 7.40, image: "img/beef-burger.jpg" },
    { id: 10, name: "Andalouse-burger", category: "Fast Food", price: 6.80, image: "img/andalouse-burger.jpg" },
    { id: 11, name: "Cola", category: "Drinks", price: 3, image: "img/cola.jpg" },
    { id: 12, name: "Cola Zero", category: "Drinks", price: 2, image: "img/cola-zerp.jpg" },
    { id: 13, name: "Fanta", category: "Drinks", price: 2, image: "img/fanta.jpg" },
    { id: 14, name: "Fanta Exotic", category: "Drinks", price: 2, image: "img/fanta-exotic.jpg" },
    { id: 15, name: "Fernandes Cherry", category: "Drinks", price: 2, image: "img/fndes-cherry.jpg" },
    { id: 16, name: "Fernandes GreenPunch", category: "Drinks", price: 2, image: "img/fndes-greenpunch.jpg" },
    { id: 17, name: "Fernandes RedGrape", category: "Drinks", price: 2, image: "img/fndes-redgrape.jpg" },
    { id: 18, name: "Ice tea", category: "Drinks", price: 2, image: "img/icetea-lipton.jpg" },
    { id: 19, name: "Sprite", category: "Drinks", price: 2, image: "img/sprite.jpg" },
    { id: 20, name: "Redbull", category: "Drinks", price: 2, image: "img/redbull.jpg" },
    { id: 21, name: "Frietjes", category: "Sides", price: 3, image: "img/friet.jpg" },
    { id: 22, name: "Kaasoufle 2 stuks", category: "Sides", price: 5, image: "img/Kaassoufle.jpg" },
    { id: 23, name: "Mais 2 stuks", category: "Sides", price: 2, image: "img/mais.jpg" },
    { id: 24, name: "Crispy Chicken Salade", category: "Sides", price: 8, image: "img/crispychickensalade.jpg" },
    { id: 25, name: "aardappalen", category: "Sides", price: 4, image: "img/aardapallen.jpg" },
    { id: 26, name: "Kipnuggets 6 stuks", category: "Sides", price: 4, image: "img/kipnuggets.jpg" },
    { id: 27, name: "Kipnuggets 12 stuks", category: "Sides", price: 8, image: "img/mozasticks.jpg" },
    { id: 28, name: "Mozarella Stick 6 stuks", category: "Sides", price: 6, image: "img/mozasticks.jpg" },
    { id: 29, name: "Mozarella Stick 12 stuks", category: "Sides", price: 6, image: "img/mozasticks.jpg" },
    { id: 30, name: "Onion Rings", category: "Sides", price: 6, image: "img/onionrings.jpg" }

];

let orderIdCounter = 0; // To generate unique IDs for each order item

// Function to display menu items of a specific category
function displayCategory(category) {
    const menuItemsContainer = document.getElementById("menuItems");
    menuItemsContainer.innerHTML = '';

    const filteredItems = menu.filter(item => item.category === category).slice(0, 10); // Display up to 10 items per category

    filteredItems.forEach(item => {
        const menuItemElement = document.createElement("div");
        menuItemElement.classList.add("menu-item");

        // Create image element
        const imgElement = document.createElement("img");
        imgElement.src = item.image;
        imgElement.alt = item.name;
        imgElement.style.width = "50%"; // Set image width (adjust as needed)
        menuItemElement.appendChild(imgElement);

        // Create item details (name and price)
        const itemDetails = document.createElement("div");
        itemDetails.classList.add("item-details");
        itemDetails.innerHTML = `
            <p>${item.name}</p>
            <p>€ ${item.price}</p>
        `;
        menuItemElement.appendChild(itemDetails);

        menuItemElement.onclick = () => {
            addToOrder(item);
        };

        menuItemsContainer.appendChild(menuItemElement);
    });
}

// Function to add item to the order
function addToOrder(item) {
    const orderList = document.getElementById("orderItems");
    const orderItem = document.createElement("li");

    orderIdCounter++; // Increment the unique ID counter
    const orderItemId = `order-item-${orderIdCounter}`;

    // Create item text (name and price)
    orderItem.innerHTML = `
        <img src="${item.image}" alt="${item.name}" style="width: 50px; vertical-align: middle; margin-right: 10px;">
        ${item.name} - €${item.price}
        <button class="remove-button" onclick="removeFromOrder('${orderItemId}')">Remove</button>
    `;
    orderItem.id = orderItemId;

    // Append order item to order list
    orderList.appendChild(orderItem);

    // Update total amount display
    updateTotalAmount();
}

// Function to remove item from the order
function removeFromOrder(orderItemId) {
    const orderItem = document.getElementById(orderItemId);
    if (orderItem) {
        orderItem.remove();
        updateTotalAmount();
    }
}

// Function to update the total amount display
function updateTotalAmount() {
    const orderItems = document.querySelectorAll("#orderItems li");
    let totalAmount = 0;

    orderItems.forEach(orderItem => {
        const price = parseFloat(orderItem.textContent.split('€')[1]);
        totalAmount += price;
    });

    const totalAmountDisplay = document.getElementById("totalAmount");
    totalAmountDisplay.textContent = `Total Amount: €${totalAmount.toFixed(2)}`;
}

// Function to place order
function placeOrder() {
    const orderList = document.getElementById("orderItems");
    if (orderList.children.length > 0) {
        const orderItems = [];
        const orderLiElements = orderList.querySelectorAll("li");

        orderLiElements.forEach(li => {
            const itemText = li.textContent.replace("Remove", "").trim();
            const name = itemText.split(' - ')[0];
            const price = parseFloat(itemText.split('€')[1]);
            const image = li.querySelector("img").src;
            orderItems.push({
                name: name,
                price: price,
                image: image
            });
        });

        const totalAmount = parseFloat(document.getElementById("totalAmount").textContent.split('$')[1]);
        
        // Store order details in localStorage
        localStorage.setItem('orderItems', JSON.stringify(orderItems));
        localStorage.setItem('totalAmount', totalAmount);
        
        // Redirect to receipt page
        window.location.href = 'receipt.html';
    } else {
        alert("Please add items to your order!");
    }
}

// Display initial category (default: Fast Food)
displayCategory('Fast Food');







